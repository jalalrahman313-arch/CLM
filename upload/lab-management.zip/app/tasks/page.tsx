"use client";

import { useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { db } from "@/lib/db";
import { generateId } from "@/lib/utils";
import { 
  ClipboardList, 
  Plus, 
  Trash2, 
  CheckCircle, 
  Circle,
  Pencil
} from "lucide-react";

export default function TasksPage() {
  const classes = useLiveQuery(() => db.classes.toArray()) || [];
  const courses = useLiveQuery(() => db.courses.toArray()) || [];
  const tasks = useLiveQuery(() => db.tasks.toArray()) || [];

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [classId, setClassId] = useState("");
  const [courseId, setCourseId] = useState("");
  
  const [editingId, setEditingId] = useState<string | null>(null);

  const pendingTasks = tasks.filter(t => t.status === "Pending").sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  const completedTasks = tasks.filter(t => t.status === "Completed").sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    if (editingId) {
      await db.tasks.update(editingId, {
        title,
        description,
        classId: classId || undefined,
        courseId: courseId || undefined
      });
      setEditingId(null);
    } else {
      await db.tasks.add({
        id: generateId(),
        title,
        description,
        status: "Pending",
        classId: classId || undefined,
        courseId: courseId || undefined,
        createdAt: new Date().toISOString()
      });
    }

    setTitle("");
    setDescription("");
    setClassId("");
    setCourseId("");
  };

  const editTask = (task: any) => {
    setEditingId(task.id);
    setTitle(task.title);
    setDescription(task.description || "");
    setClassId(task.classId || "");
    setCourseId(task.courseId || "");
  };

  const cancelEdit = () => {
    setEditingId(null);
    setTitle("");
    setDescription("");
    setClassId("");
    setCourseId("");
  };

  const toggleStatus = async (task: any) => {
    await db.tasks.update(task.id, {
      status: task.status === "Pending" ? "Completed" : "Pending"
    });
  };

  const deleteTask = async (id: string) => {
    if (confirm("کیا آپ واقعی یہ ٹاسک حذف کرنا چاہتے ہیں؟")) {
      await db.tasks.delete(id);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <ClipboardList className="w-6 h-6 text-accent" />
          ٹاسکس (کاموں کی فہرست)
        </h1>
        <p className="text-text-muted mt-1">اپنے کاموں اور پراجیکٹس کا اندراج کریں</p>
      </header>

      {/* Task Form */}
      <section className="glass-card p-6">
        <h2 className="text-lg font-bold mb-4">{editingId ? "ٹاسک میں ترمیم کریں" : "نیا ٹاسک شامل کریں"}</h2>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 col-span-1 md:col-span-2">
              <label className="text-sm font-medium">عنوان *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-2 bg-surface-light border border-border-subtle rounded-xl focus:ring-1 focus:ring-accent focus:border-accent outline-none"
                placeholder="ٹاسک کا عنوان لکھیں..."
              />
            </div>
            
            <div className="space-y-2 col-span-1 md:col-span-2">
              <label className="text-sm font-medium">تفصیل (اختیاری)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                className="w-full px-4 py-2 bg-surface-light border border-border-subtle rounded-xl focus:ring-1 focus:ring-accent focus:border-accent outline-none font-sans"
                placeholder="مزید تفصیلات..."
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-text-muted">منسلک کلاس (اختیاری)</label>
              <div className="relative">
                <select
                  value={classId}
                  onChange={(e) => setClassId(e.target.value)}
                  className="w-full appearance-none pl-10 pr-4 py-2 bg-surface-light border border-border-subtle rounded-xl focus:ring-1 focus:ring-accent focus:border-accent outline-none font-sans"
                >
                  <option value="">کوئی نہیں</option>
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-text-muted">منسلک کورس (اختیاری)</label>
              <div className="relative">
                <select
                  value={courseId}
                  onChange={(e) => setCourseId(e.target.value)}
                  className="w-full appearance-none pl-10 pr-4 py-2 bg-surface-light border border-border-subtle rounded-xl focus:ring-1 focus:ring-accent focus:border-accent outline-none font-sans"
                >
                  <option value="">کوئی نہیں</option>
                  {courses.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              type="submit"
              className="flex items-center justify-center gap-2 px-6 py-2 bg-accent text-white rounded-xl hover:bg-accent/90 transition-colors"
            >
              <Plus className="w-4 h-4" />
              {editingId ? "محفوظ کریں" : "شامل کریں"}
            </button>
            {editingId && (
              <button
                type="button"
                onClick={cancelEdit}
                className="px-6 py-2 bg-surface-light text-text-muted rounded-xl hover:bg-surface-base transition-colors"
              >
                منسوخ کریں
              </button>
            )}
          </div>
        </form>
      </section>

      {/* Pending Tasks */}
      <section>
        <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Circle className="w-5 h-5 text-accent" />
          بقایا کام ({pendingTasks.length})
        </h2>
        {pendingTasks.length === 0 ? (
          <div className="glass-card p-8 text-center text-text-muted">
            کوئی بقایا کام نہیں۔
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {pendingTasks.map((task) => {
              const cls = classes.find(c => c.id === task.classId);
              const crs = courses.find(c => c.id === task.courseId);

              return (
                <div key={task.id} className="glass-card p-5 border-l-4 border-l-accent flex flex-col justify-between hover:shadow-md transition-shadow">
                  <div>
                    <h3 className="font-bold text-lg leading-tight">{task.title}</h3>
                    {task.description && (
                      <p className="text-sm text-text-muted mt-2 line-clamp-2">{task.description}</p>
                    )}

                    <div className="mt-3 flex flex-wrap gap-1">
                      {cls && (
                        <span className="text-xs px-2 py-1 bg-surface-light rounded-md border border-border-subtle">
                          کلاس: {cls.name}
                        </span>
                      )}
                      {crs && (
                        <span className="text-xs px-2 py-1 bg-surface-light rounded-md border border-border-subtle">
                          کورس: {crs.name}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 mt-4 pt-3 border-t border-border-subtle">
                    <button
                      onClick={() => toggleStatus(task)}
                      className="p-2 text-text-muted hover:text-emerald-500 hover:bg-emerald-500/10 rounded-lg transition-colors"
                      title="مکمل کریں"
                    >
                      <CheckCircle className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => editTask(task)}
                      className="p-2 text-text-muted hover:text-blue-500 hover:bg-blue-500/10 rounded-lg transition-colors"
                      title="ترمیم"
                    >
                      <Pencil className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => deleteTask(task.id)}
                      className="p-2 text-text-muted hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                      title="حذف کریں"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Completed Tasks */}
      {completedTasks.length > 0 && (
        <section className="opacity-75">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-500" />
            مکمل شدہ ({completedTasks.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {completedTasks.map((task) => {
              const cls = classes.find(c => c.id === task.classId);
              const crs = courses.find(c => c.id === task.courseId);

              return (
                <div key={task.id} className="glass-card p-4 border-l-4 border-l-emerald-500 bg-surface-light/50">
                  <h3 className="font-bold line-through text-text-muted">{task.title}</h3>
                  <div className="flex items-center justify-end gap-2 mt-3 pt-2">
                    <button
                      onClick={() => toggleStatus(task)}
                      className="text-xs px-3 py-1.5 bg-surface-base border border-border-subtle rounded-lg text-text-muted hover:text-accent hover:border-accent/30 transition-colors"
                    >
                      دوبارہ بحال کریں
                    </button>
                    <button
                      onClick={() => deleteTask(task.id)}
                      className="p-1.5 text-text-muted hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                      title="حذف کریں"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
